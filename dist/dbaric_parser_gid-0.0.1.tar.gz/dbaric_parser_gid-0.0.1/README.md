# BigData_Parser
Parsing ADAS Big Data files
